
 import React from 'react';
 import { View, Button, StyleSheet } from 'react-native';

 export default class home extends React.Component {

    render() {
        return(
         <View style={{ marginTop: 50}}>
 

             <View style={{ margin: 5}}>
                <Button style={styles.ButtonStyle} onPress={()=>this.props.navigation.replace('MyMap')}
                        title="My Map"
                />
             </View>

              <View style={{ margin: 5}}>
                <Button style={styles.ButtonStyle} onPress={()=>this.props.navigation.replace('camera')}
                        title="Take/Share/Save Photo"
                />
             </View>

          
   

            
         </View>
        )
    }

  }

  const styles = StyleSheet.create({
       ButtonStyle: {
                marginTop:15,
                marginLeft:40,
                marginRight:40,
                textAlign:'center',
                borderRadius:10,
                padding:10,
                elevation:3,
                alignItems:'center',
                
            },
 
  });