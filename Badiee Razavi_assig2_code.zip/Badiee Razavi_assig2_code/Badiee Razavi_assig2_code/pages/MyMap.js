import * as React from 'react'
import MapView from 'react-native-maps'
import * as Location from 'expo-location'
import * as Permissions from 'expo-permissions'
import { StyleSheet, Button, View } from 'react-native'

const { useState, useEffect } = React

export default function MapScreen() {

    const [ locationResult, setLocation ] = useState( null )
    const [ mapRegion, setRegion ] = useState( null )
    const [ hasLocationPermissions, setLocationPermission ] = useState( false )

    useEffect( () => {
        const getLocationAsync = async () => {
            let { status } = await Permissions.askAsync( Permissions.LOCATION )
            if ( 'granted' !== status ) {
                setLocation( 'Permission to access location was denied' )
            } else {
                setLocationPermission( true );
            }

            let { coords: { latitude, longitude } } = await Location.getCurrentPositionAsync({})
            setLocation( JSON.stringify( { latitude, longitude } ) )
            
            // Center the map on the location we just fetched.
            setRegion( { latitude, longitude, latitudeDelta: 0.0922, longitudeDelta: 0.0421 } );
        }

        getLocationAsync()
    } )
 
 
    return (
            <MapView
                style={ styles.container }
                region={ mapRegion }
                initialRegion={{
                    "latitude": 56.853022,
                    "latitudeDelta": 0.0922,
                    "longitude": 14.824686,
                    "longitudeDelta": 0.0421,
                }}
                onRegionChange={ region => setRegion( region )}
            >
                <MapView.Marker
                    title="Current location"
                    description=" latitude:56.853022, longitude:14.824686 "
                    coordinate={{"latitude":56.853022,"longitude":14.824686}}
                    
                />
            </MapView>

    )
}



MapScreen.navigationOptions = {
    header: null
}




const styles = StyleSheet.create({
    container: {
      marginTop:20,
      marginBottom:50,
      alignItems:'center',
      flex: 1,
    },
})