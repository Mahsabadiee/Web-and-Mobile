import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack'


import HomeScreen from './pages/Home.js'
import MyMap from './pages/MyMap.js'
import camera from './pages/camera.js'


const MainNavigator = createStackNavigator({
  home: { screen: HomeScreen },
  MyMap: { screen: MyMap },
  camera: { screen: camera },

},
  {
    headerMode: 'none' , 
  }
);

const App = createAppContainer(MainNavigator);

export default App;